# Bablu Kumar UPI Payment Page

A static UPI intent + dynamic QR page for UPI ID `Demogh@ybl`.

## Publish with GitHub Pages
1. Create a public GitHub repository, for example `bablu-upi-payment`.
2. Upload `index.html` to the repository root.
3. Open Settings -> Pages.
4. Under Build and deployment, choose Deploy from a branch.
5. Select `main` and `/ (root)`, then Save.
6. Wait for GitHub Pages to publish the site. The URL will look like:
   `https://YOUR-USERNAME.github.io/bablu-upi-payment/`

## Important
This page only launches a UPI payment request and generates a QR. It does NOT verify payment or receive bank callbacks. Check the actual credit in your bank/UPI app before treating an order as paid. Do not rely on screenshots or user-entered transaction IDs.
